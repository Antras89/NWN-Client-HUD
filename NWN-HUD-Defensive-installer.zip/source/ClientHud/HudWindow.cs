using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace ClientHud;

public sealed class HudWindow : Window
{
	private readonly string _root = AppContext.BaseDirectory;

	private readonly Settings _settings;

	private readonly Tracker _tracker;

	private readonly LogTail _tail;

	private readonly Dictionary<string, IconInfo> _icons;

	private readonly StackPanel _body = new StackPanel();

	private ScrollViewer? _scrollViewer;

	private Thumb? _resizeGrip;

	private readonly TextBlock _status = new TextBlock
	{
		Foreground = Brushes.LightGray,
		FontSize = 11.0,
		TextWrapping = TextWrapping.Wrap,
		Margin = new Thickness(5.0)
	};

	private readonly Button _collapse = new Button
	{
		Content = "▾",
		Width = 26.0,
		Height = 24.0,
		ToolTip = "Collapse / expand"
	};

	private readonly DispatcherTimer _timer = new DispatcherTimer
	{
		Interval = TimeSpan.FromMilliseconds(100L)
	};

	private readonly Dictionary<string, BitmapImage> _imageCache = new Dictionary<string, BitmapImage>(StringComparer.OrdinalIgnoreCase);

	private readonly Stopwatch _clock = Stopwatch.StartNew();

	private readonly DateTimeOffset _started = DateTimeOffset.UtcNow;

	private string _signature = "";

	private string _savedLearned = "";

	private double _expandedHeight;

	private readonly bool _preview;

	private DateTimeOffset Now => _started + _clock.Elapsed;

	public HudWindow(bool preview)
	{
		HudWindow hudWindow = this;
		_preview = preview;
		_settings = Load<Settings>("settings.json") ?? new Settings();
		_icons = new Dictionary<string, IconInfo>(Load<Dictionary<string, IconInfo>>("icons.json") ?? new Dictionary<string, IconInfo>(), StringComparer.OrdinalIgnoreCase);
		_tracker = new Tracker(_settings.Character, from entry in _icons
			where entry.Value.IsStance
			select entry.Key);
		_tracker.DebuffNames.UnionWith(from entry in _icons
			where entry.Value.Group == "debuff"
			select entry.Key);
		BuffDurationCatalog buffDurationCatalog = Load<BuffDurationCatalog>("buff-durations.json");
		string key;
		if (buffDurationCatalog != null)
		{
			foreach (KeyValuePair<string, BuffDuration> effect in buffDurationCatalog.Effects)
			{
				effect.Deconstruct(out key, out var value);
				string key2 = key;
				BuffDuration value2 = value;
				_tracker.BaseDurations[key2] = value2;
			}
		}
		Dictionary<string, double> dictionary = Load<Dictionary<string, double>>("learned.json");
		if (dictionary != null)
		{
			foreach (KeyValuePair<string, double> item2 in dictionary)
			{
				item2.Deconstruct(out key, out var value3);
				string key3 = key;
				double value4 = value3;
				_tracker.Learned[key3] = value4;
			}
		}
		_tail = new LogTail(_settings.LogPath);
		if (!preview)
		{
			_tail.OnTrackedEvent = WriteDiagnostic;
		}
		base.Title = "NWN Client HUD";
		base.MinWidth = _settings.CompactMode ? 200 : 230;
		base.MinHeight = _settings.CompactMode ? 100 : 140;
		base.Width = Math.Clamp(_settings.Width, MinWidth, Math.Max(MinWidth, SystemParameters.WorkArea.Width));
		base.Height = (_expandedHeight = Math.Clamp(_settings.Height, MinHeight, Math.Max(MinHeight, SystemParameters.WorkArea.Height)));
		base.SizeToContent = SizeToContent.Manual;
		base.WindowStyle = WindowStyle.None;
		base.AllowsTransparency = true;
		base.Background = Brushes.Transparent;
		base.ResizeMode = ResizeMode.NoResize;
		base.Topmost = true;
		base.ShowActivated = true;
		base.Left = ((_settings.Left >= 0.0) ? _settings.Left : Math.Max(0.0, SystemParameters.WorkArea.Right - base.Width - 55.0));
		base.Left = Math.Clamp(Left, SystemParameters.WorkArea.Left, Math.Max(SystemParameters.WorkArea.Left, SystemParameters.WorkArea.Right - Width));
		base.Top = Math.Clamp(_settings.Top, SystemParameters.WorkArea.Top, Math.Max(SystemParameters.WorkArea.Top, SystemParameters.WorkArea.Bottom - Height));
		Grid grid = new Grid
		{
			RowDefinitions = 
			{
				new RowDefinition
				{
					Height = GridLength.Auto
				},
				new RowDefinition
				{
					Height = new GridLength(1.0, GridUnitType.Star)
				},
				new RowDefinition
				{
					Height = GridLength.Auto
				}
			}
		};
		DockPanel dockPanel = new DockPanel
		{
			Background = new SolidColorBrush(Color.FromArgb(100, 10, 15, 23))
		};
		DockPanel.SetDock(_collapse, Dock.Left);
		dockPanel.Children.Add(_collapse);
		TextBlock textBlock = new TextBlock
		{
			Text = " EFFECTS",
			Foreground = Brushes.White,
			FontSize = 12.0,
			VerticalAlignment = VerticalAlignment.Center,
			Cursor = Cursors.SizeAll,
			ToolTip = "Drag to move the panel"
		};
		textBlock.MouseLeftButtonDown += delegate
		{
			hudWindow.DragMove();
		};
		Button button = new Button
		{
			Content = "×",
			Width = 26.0,
			Height = 24.0,
			ToolTip = "Close overlay"
		};
		DockPanel.SetDock(button, Dock.Right);
		button.Click += delegate
		{
			hudWindow.Close();
		};
		dockPanel.Children.Add(button);
		Button options = new Button
		{
			Content = "⚙",
			FontFamily = new FontFamily("Segoe UI Symbol"),
			Width = 26.0,
			Height = 24.0,
			ToolTip = "Settings"
		};
		DockPanel.SetDock(options, Dock.Right);
		dockPanel.Children.Add(options);
		ContextMenu menu = new ContextMenu();
		MenuItem compactMode = Choice("Compact mode", _settings.CompactMode, value =>
		{
			_settings.CompactMode = value;
		});
		compactMode.ToolTip = "Smaller icons and spacing; hides empty sections. Full effect names remain in tooltips.";
		MenuItem fitPanel = new MenuItem { Header = "Small panel", ToolTip = "Set a compact 280 x 360 panel and keep it inside the screen." };
		fitPanel.Click += delegate
		{
			_settings.CompactMode = true;
			compactMode.IsChecked = true;
			Rect area = SystemParameters.WorkArea;
			MinWidth = 200;
			MinHeight = 100;
			Width = Math.Max(MinWidth, Math.Min(280, area.Width));
			_expandedHeight = Math.Max(100, Math.Min(360, area.Height));
			if (_scrollViewer != null) _scrollViewer.Visibility = Visibility.Visible;
			if (_resizeGrip != null) _resizeGrip.Visibility = Visibility.Visible;
			_collapse.Content = "▾";
			Height = _expandedHeight;
			Left = Math.Clamp(Left, area.Left, Math.Max(area.Left, area.Right - Width));
			Top = Math.Clamp(Top, area.Top, Math.Max(area.Top, area.Bottom - Height));
			_settings.Width = Width;
			_settings.Height = _expandedHeight;
			ApplyOptions();
		};
		menu.Items.Add(fitPanel);
		menu.Items.Add(new Separator());
		MenuItem checkCharacterName = new MenuItem
		{
			Header = "Check character name",
			ToolTip = "Detect your character from skill and effect entries in the NWN chat log."
		};
		checkCharacterName.Click += delegate
		{
			try
			{
				string? detectedName = CharacterNameDetector.Detect(_settings.LogPath);
				if (string.IsNullOrWhiteSpace(detectedName))
				{
					MessageBox.Show("No character name was found in the game log. Activate a skill, then check again.", "NWN Client HUD");
					return;
				}
				_settings.Character = detectedName;
				_tracker.Character = detectedName;
				_tail.Rewind(_tracker);
				_tail.Poll(_tracker);
				ApplyOptions();
				MessageBox.Show("Character name set to " + detectedName + ".", "NWN Client HUD");
			}
			catch (IOException)
			{
				MessageBox.Show("Cannot read the game log.", "NWN Client HUD");
			}
			catch (UnauthorizedAccessException)
			{
				MessageBox.Show("Cannot access the game log.", "NWN Client HUD");
			}
		};
		menu.Items.Add(checkCharacterName);
		menu.Items.Add(new Separator());
		MenuItem showDebuffs = Choice("Show debuffs", _settings.ShowDebuffs, delegate(bool showDebuffs2)
		{
			hudWindow._settings.ShowDebuffs = showDebuffs2;
		});
		Choice("Hide unconfirmed debuffs after 60 seconds", _settings.HideStaleDebuffs, delegate(bool hideStaleDebuffs)
		{
			hudWindow._settings.HideStaleDebuffs = hideStaleDebuffs;
		}).ToolTip = "Only affects debuffs with unknown duration. Hiding an old log entry does not confirm that the effect has ended.";
		MenuItem showStances = Choice("Show stances", _settings.ShowStances, delegate(bool showStances2)
		{
			hudWindow._settings.ShowStances = showStances2;
		});
		MenuItem transparent = Choice("Transparent background", _settings.TransparentBackground, delegate(bool transparentBackground)
		{
			hudWindow._settings.TransparentBackground = transparentBackground;
		});
		MenuItem durationBars = Choice("Show duration bars", _settings.ShowDurationBars, delegate(bool showDurationBars)
		{
			hudWindow._settings.ShowDurationBars = showDurationBars;
		});
		MenuItem fullRowBars = Choice("Full-row duration bars", _settings.FullRowDurationBars, delegate(bool fullRowDurationBars)
		{
			hudWindow._settings.FullRowDurationBars = fullRowDurationBars;
		});
		fullRowBars.ToolTip = "Use a large green background behind the skill name and time instead of a thin bar";
		Choice("Estimate silent buff refreshes", _settings.EstimateSilentBuffRefreshes, delegate(bool estimateSilentBuffRefreshes)
		{
			hudWindow._settings.EstimateSilentBuffRefreshes = estimateSilentBuffRefreshes;
		});
		MenuItem menuItem = new MenuItem
		{
			Header = "Open HUD log"
		};
		menuItem.Click += delegate
		{
			hudWindow.WriteDiagnostic("Diagnostics opened");
			Process.Start(new ProcessStartInfo("notepad.exe", "\"" + Path.Combine(hudWindow._root, "hud-diagnostic.log") + "\"")
			{
				UseShellExecute = true
			});
		};
		menu.Items.Add(menuItem);
		menu.Items.Add(new Separator());
		MenuItem menuItem2 = new MenuItem
		{
			Header = "Refresh HUD",
			ToolTip = "Clear the displayed effects and track new log entries. Existing buffs appear when the log reports them again."
		};
		menuItem2.Click += delegate
		{
			try
			{
				hudWindow._tail.Refresh(hudWindow._tracker);
				hudWindow._signature = "";
				hudWindow.Render();
			}
			catch (IOException)
			{
				MessageBox.Show("Cannot refresh while the game log is unavailable.", "NWN Client HUD");
			}
			catch (UnauthorizedAccessException)
			{
				MessageBox.Show("Cannot access the game log.", "NWN Client HUD");
			}
		};
		menu.Items.Add(menuItem2);
		MenuItem startup = new MenuItem
		{
			Header = "Start with NWN",
			ToolTip = "Start the background watcher when you sign in to Windows",
			IsCheckable = true,
			IsChecked = StartupRegistration.IsEnabled()
		};
		startup.Click += delegate
		{
			try
			{
				StartupRegistration.SetEnabled(startup.IsChecked);
			}
			catch
			{
				startup.IsChecked = StartupRegistration.IsEnabled();
				MessageBox.Show("Could not update the Windows startup setting.", "NWN Client HUD");
			}
		};
		menu.Items.Add(startup);
		MenuItem menuItem3 = new MenuItem
		{
			Header = "Exit HUD"
		};
		menuItem3.Click += delegate
		{
			Application.Current.Shutdown();
		};
		menu.Items.Add(menuItem3);
		options.Click += delegate
		{
			startup.IsChecked = StartupRegistration.IsEnabled();
			menu.PlacementTarget = options;
			menu.Placement = PlacementMode.Bottom;
			menu.IsOpen = true;
		};
		dockPanel.Children.Add(textBlock);
		ScrollViewer scroll = _scrollViewer = new ScrollViewer
		{
			Content = _body,
			VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
			HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled
		};
		Grid.SetRow(scroll, 1);
		Thumb grip = _resizeGrip = new Thumb
		{
			Width = 22.0,
			Height = 18.0,
			HorizontalAlignment = HorizontalAlignment.Right,
			Cursor = Cursors.SizeNWSE,
			ToolTip = "Drag to resize the panel"
		};
		FrameworkElementFactory frameworkElementFactory = new FrameworkElementFactory(typeof(TextBlock));
		frameworkElementFactory.SetValue(TextBlock.TextProperty, "◢");
		frameworkElementFactory.SetValue(TextBlock.ForegroundProperty, Brushes.LightGray);
		frameworkElementFactory.SetValue(TextBlock.BackgroundProperty, new SolidColorBrush(Color.FromArgb(90, 10, 15, 23)));
		frameworkElementFactory.SetValue(TextBlock.TextAlignmentProperty, TextAlignment.Right);
		grip.Template = new ControlTemplate(typeof(Thumb))
		{
			VisualTree = frameworkElementFactory
		};
		grip.DragDelta += delegate(object _, DragDeltaEventArgs e)
		{
			hudWindow.Width = Math.Clamp(hudWindow.Width + e.HorizontalChange, hudWindow.MinWidth, Math.Max(hudWindow.MinWidth, SystemParameters.WorkArea.Width));
			double minimum = hudWindow._settings.CompactMode ? 100 : 140;
			hudWindow.Height = Math.Clamp(hudWindow.Height + e.VerticalChange, minimum, Math.Max(minimum, SystemParameters.WorkArea.Height));
			hudWindow._expandedHeight = hudWindow.Height;
		};
		Grid.SetRow(grip, 2);
		_collapse.Click += delegate
		{
			bool flag = scroll.Visibility == Visibility.Visible;
			if (flag)
			{
				hudWindow._expandedHeight = hudWindow.Height;
			}
			ScrollViewer scrollViewer = scroll;
			Visibility visibility = (grip.Visibility = (flag ? Visibility.Collapsed : Visibility.Visible));
			scrollViewer.Visibility = visibility;
			hudWindow.MinHeight = (flag ? 24 : (_settings.CompactMode ? 100 : 140));
			hudWindow.Height = (flag ? 24.0 : hudWindow._expandedHeight);
			hudWindow._collapse.Content = (flag ? "▸" : "▾");
		};
		grid.Children.Add(dockPanel);
		grid.Children.Add(scroll);
		grid.Children.Add(grip);
		base.Content = grid;
		ApplyOptions();
		_timer.Tick += delegate
		{
			hudWindow.Tick();
		};
		base.Closing += delegate
		{
			hudWindow._timer.Stop();
			if (!preview)
			{
				hudWindow._settings.Left = hudWindow.Left;
				hudWindow._settings.Top = hudWindow.Top;
				hudWindow._settings.Width = hudWindow.Width;
				hudWindow._settings.Height = ((scroll.Visibility == Visibility.Visible) ? hudWindow.Height : hudWindow._expandedHeight);
				hudWindow.Save("settings.json", hudWindow._settings);
				hudWindow.Save("learned.json", hudWindow._tracker.Learned);
			}
		};
		base.Loaded += delegate
		{
			if (preview)
			{
				hudWindow._tracker.Effects["Rampart"] = new EffectState
				{
					Name = "Rampart",
					Applied = hudWindow.Now,
					Ends = hudWindow.Now.AddSeconds(28.0),
					DurationSeconds = 60.0,
					Estimated = true
				};
				hudWindow._tracker.Effects["Soul Devourer Stance"] = new EffectState
				{
					Name = "Soul Devourer Stance",
					Applied = hudWindow.Now,
					Permanent = true
				};
				hudWindow._tracker.Effects["Disoriented"] = new EffectState
				{
					Name = "Disoriented",
					Applied = hudWindow.Now
				};
				hudWindow._tracker.Effects["Blazing Spikes"] = new EffectState
				{
					Name = "Blazing Spikes",
					Applied = hudWindow.Now,
					Permanent = true
				};
				hudWindow._tracker.Effects["Renewal III"] = new EffectState
				{
					Name = "Renewal III",
					Applied = hudWindow.Now,
					Ends = hudWindow.Now.AddSeconds(20.0),
					DurationSeconds = 30.0
				};
				hudWindow.Render();
				bool showDebuffs2 = hudWindow._settings.ShowDebuffs;
				bool showStances2 = hudWindow._settings.ShowStances;
				bool transparentBackground = hudWindow._settings.TransparentBackground;
				bool showDurationBars = hudWindow._settings.ShowDurationBars;
				bool fullRowDurationBars = hudWindow._settings.FullRowDurationBars;
				showDebuffs.IsChecked = false;
				showDebuffs.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				showStances.IsChecked = false;
				showStances.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				if (hudWindow.VisibleEffects().Any((EffectState e) => e.Name == "Disoriented" || e.Name == "Soul Devourer Stance"))
				{
					throw new InvalidOperationException("Visibility options verification failed.");
				}
				transparent.IsChecked = false;
				transparent.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				if (!(hudWindow.Background is SolidColorBrush { Color: { A: byte.MaxValue } }))
				{
					throw new InvalidOperationException("Opaque background verification failed.");
				}
				showDebuffs.IsChecked = showDebuffs2;
				showDebuffs.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				showStances.IsChecked = showStances2;
				showStances.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				transparent.IsChecked = transparentBackground;
				transparent.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				durationBars.IsChecked = false;
				durationBars.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				if (hudWindow._body.Children.OfType<StackPanel>().SelectMany((StackPanel panel) => panel.Children.OfType<Grid>()).Any((Grid row) => row.Children.OfType<ProgressBar>().Any()))
				{
					throw new InvalidOperationException("Duration bar visibility verification failed.");
				}
				durationBars.IsChecked = showDurationBars;
				durationBars.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				durationBars.IsChecked = true;
				durationBars.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				fullRowBars.IsChecked = true;
				fullRowBars.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				Grid[] array = (from bar in hudWindow._body.Children.OfType<StackPanel>().SelectMany((StackPanel panel) => panel.Children.OfType<Grid>()).SelectMany((Grid row) => row.Children.OfType<Grid>())
					where object.Equals(bar.Tag, "DurationBackground")
					select bar).ToArray();
				if (array.Length != 2 || array[0].ColumnDefinitions[0].Width.Value <= 0.0 || array[0].ColumnDefinitions[0].Width.Value >= 1.0)
				{
					throw new InvalidOperationException("Full-row duration bar verification failed.");
				}
				durationBars.IsChecked = false;
				durationBars.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				if (hudWindow._body.Children.OfType<StackPanel>().SelectMany((StackPanel panel) => panel.Children.OfType<Grid>()).SelectMany((Grid row) => row.Children.OfType<Grid>())
					.Any((Grid bar) => object.Equals(bar.Tag, "DurationBackground")))
				{
					throw new InvalidOperationException("Full-row duration bar hiding verification failed.");
				}
				fullRowBars.IsChecked = fullRowDurationBars;
				fullRowBars.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				durationBars.IsChecked = showDurationBars;
				durationBars.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
				double width = hudWindow.Width;
				double height = hudWindow.Height;
				grip.RaiseEvent(new DragDeltaEventArgs(40.0, 40.0)
				{
					RoutedEvent = Thumb.DragDeltaEvent
				});
				double height2 = hudWindow.Height;
				if (hudWindow.Width <= width || height2 <= height)
				{
					throw new InvalidOperationException("Resize verification failed.");
				}
				hudWindow._collapse.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
				if (hudWindow.Height != 24.0 || scroll.Visibility != Visibility.Collapsed)
				{
					throw new InvalidOperationException("Collapse verification failed.");
				}
				hudWindow._collapse.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
				if (hudWindow.Height != height2 || scroll.Visibility != Visibility.Visible)
				{
					throw new InvalidOperationException("Expand verification failed.");
				}
				hudWindow.Width = width;
				hudWindow.Height = (hudWindow._expandedHeight = height);
				hudWindow.Dispatcher.BeginInvoke((Action)delegate
				{
					hudWindow.UpdateLayout();
					RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap((int)hudWindow.ActualWidth, (int)hudWindow.ActualHeight, 96.0, 96.0, PixelFormats.Pbgra32);
					renderTargetBitmap.Render((Visual)hudWindow.Content);
					PngBitmapEncoder pngBitmapEncoder = new PngBitmapEncoder
					{
						Frames = { BitmapFrame.Create(renderTargetBitmap) }
					};
					using (FileStream stream = File.Create(Path.Combine(hudWindow._root, "podglad.png")))
					{
						pngBitmapEncoder.Save(stream);
					}
					hudWindow.Close();
				}, DispatcherPriority.ApplicationIdle);
			}
			else
			{
				hudWindow.Tick();
				hudWindow._timer.Start();
			}
		};
		MenuItem Choice(string text, bool isChecked, Action<bool> change)
		{
			MenuItem item = new MenuItem
			{
				Header = text,
				IsCheckable = true,
				IsChecked = isChecked,
				StaysOpenOnClick = true
			};
			item.Click += delegate
			{
				change(item.IsChecked);
				hudWindow.ApplyOptions();
			};
			menu.Items.Add(item);
			return item;
		}
	}

	private T? Load<T>(string file)
	{
		string path = Path.Combine(_root, file);
		if (!File.Exists(path))
		{
			return default(T);
		}
		return JsonSerializer.Deserialize<T>(File.ReadAllText(path));
	}

	private void Save<T>(string file, T data)
	{
		string text = Path.Combine(_root, file);
		File.WriteAllText(text + ".tmp", JsonSerializer.Serialize(data, new JsonSerializerOptions
		{
			WriteIndented = true
		}));
		File.Move(text + ".tmp", text, overwrite: true);
	}

	private void Tick()
	{
		try
		{
			_tail.Poll(_tracker);
			string text = JsonSerializer.Serialize(_tracker.Learned);
			if (text != _savedLearned)
			{
				Save("learned.json", _tracker.Learned);
				_savedLearned = text;
			}
			_status.Text = "~ estimated duration\n" + _settings.Character + " · Log read: " + (_tail.LastReadAt?.ToString("HH:mm:ss") ?? "waiting");
		}
		catch (IOException)
		{
			_status.Text = "Waiting for the game log…";
		}
		catch (UnauthorizedAccessException)
		{
			_status.Text = "Cannot access the game log.";
		}
		Render();
	}

	private void WriteDiagnostic(string message)
	{
		try
		{
			string text = Path.Combine(_root, "hud-diagnostic.log");
			if (File.Exists(text) && new FileInfo(text).Length > 1048576)
			{
				File.Move(text, text + ".previous", overwrite: true);
			}
			File.AppendAllText(text, DateTimeOffset.Now.ToString("O") + " " + message + Environment.NewLine);
		}
		catch (IOException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
	}

	private bool IsStance(EffectState effect)
	{
		if (!Tracker.IsBlazingSpikes(effect.Name))
		{
			IconInfo? valueOrDefault = _icons.GetValueOrDefault(effect.Name);
			if (valueOrDefault == null || !valueOrDefault.IsStance)
			{
				return effect.Name.EndsWith(" Stance", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
		return false;
	}

	private IEnumerable<EffectState> VisibleEffects()
	{
		return from effect in _tracker.Active(Now)
			where _settings.ShowStances || !IsStance(effect)
			where _settings.ShowDebuffs || _icons.GetValueOrDefault(effect.Name)?.Group != "debuff"
			select effect;
	}

	private void ApplyOptions()
	{
		MinWidth = _settings.CompactMode ? 200 : 230;
		if (Height > 24) MinHeight = _settings.CompactMode ? 100 : 140;
		_tracker.EstimateSilentBuffRefreshes = _settings.EstimateSilentBuffRefreshes;
		_tracker.HideStaleDebuffs = _settings.HideStaleDebuffs;
		base.Background = (_settings.TransparentBackground ? Brushes.Transparent : new SolidColorBrush(Color.FromRgb(16, 22, 29)));
		_signature = "";
		Render();
		if (!_preview)
		{
			_settings.Left = base.Left;
			_settings.Top = base.Top;
			_settings.Width = base.Width;
			_settings.Height = ((base.Height > 24.0) ? base.Height : _expandedHeight);
			Save("settings.json", _settings);
		}
	}

	private void Render()
	{
		EffectState[] source = VisibleEffects().ToArray();
		string text = string.Join('|', source.Select((EffectState e) => e.Name + Tracker.Display(e, Now) + e.Applied.Ticks + e.DurationSeconds + e.TimingSource + (_settings.ShowDurationBars ? Tracker.FractionRemaining(e, Now).ToString("F3", CultureInfo.InvariantCulture) : ""))) + _status.Text;
		if (text == _signature)
		{
			return;
		}
		_signature = text;
		_body.Children.Clear();
		string[] array = new string[6] { "stance", "healing", "defensive", "buff", "debuff", "other" };
		foreach (string group in array)
		{
			if ((group == "stance" && !_settings.ShowStances) || (group == "debuff" && !_settings.ShowDebuffs))
			{
				continue;
			}
			EffectState[] array2 = source.Where((EffectState e) => (Tracker.IsDefensiveEffect(e.Name) ? "defensive" : (IsStance(e) ? "stance" : (Tracker.IsHealingEffect(e.Name) ? "healing" : (_icons.GetValueOrDefault(e.Name)?.Group ?? "other")))) == group).ToArray();
			if ((group == "other" || _settings.CompactMode) && array2.Length == 0)
			{
				continue;
			}
			SolidColorBrush solidColorBrush;
			if (group == "debuff")
			{
				solidColorBrush = Brushes.LightCoral;
			}
			else
			{
				bool flag;
				switch (group)
				{
				case "buff":
				case "stance":
				case "healing":
				case "defensive":
					flag = true;
					break;
				default:
					flag = false;
					break;
				}
				solidColorBrush = (flag ? Brushes.LightGreen : Brushes.LightGray);
			}
			SolidColorBrush solidColorBrush2 = solidColorBrush;
			_body.Children.Add(new TextBlock
			{
				Text = ((group == "stance") ? "STANCES" : ((group == "healing") ? "HEALING" : ((group == "defensive") ? "DEFENSIVE" : ((group == "buff") ? "BUFFS" : ((group == "debuff") ? "DEBUFFS" : "OTHER EFFECTS"))))),
				Foreground = solidColorBrush2,
				FontSize = _settings.CompactMode ? 12.0 : 16.0,
				FontWeight = FontWeights.Bold,
				Margin = _settings.CompactMode ? new Thickness(4, 4, 0, 2) : new Thickness(4.0, 12.0, 0.0, 5.0)
			});
			StackPanel stackPanel = new StackPanel();
			EffectState[] array3 = array2;
			foreach (EffectState effectState in array3)
			{
				Grid grid = new Grid
				{
					Margin = _settings.CompactMode ? new Thickness(2, 1, 2, 1) : new Thickness(2.0, 2.0, 2.0, 2.0),
					Background = null,
					ToolTip = effectState.Name + "\n" + effectState.TimingSource
				};
				grid.ColumnDefinitions.Add(new ColumnDefinition
				{
					Width = new GridLength(_settings.CompactMode ? 24 : 36)
				});
				grid.ColumnDefinitions.Add(new ColumnDefinition
				{
					Width = new GridLength(1.0, GridUnitType.Star)
				});
				grid.ColumnDefinitions.Add(new ColumnDefinition
				{
					Width = new GridLength(_settings.CompactMode ? 58 : 62)
				});
				grid.RowDefinitions.Add(new RowDefinition
				{
					Height = GridLength.Auto
				});
				grid.RowDefinitions.Add(new RowDefinition
				{
					Height = GridLength.Auto
				});
				string text2 = Path.Combine(_root, "icons", _icons.GetValueOrDefault(effectState.Name)?.Icon + ".png");
				FrameworkElement element;
				if (File.Exists(text2))
				{
					if (!_imageCache.TryGetValue(text2, out BitmapImage value))
					{
						value = new BitmapImage();
						value.BeginInit();
						value.CacheOption = BitmapCacheOption.OnLoad;
						value.UriSource = new Uri(text2);
						value.EndInit();
						value.Freeze();
						_imageCache[text2] = value;
					}
					element = new Image
					{
						Source = value,
						Width = _settings.CompactMode ? 22 : 32,
						Height = _settings.CompactMode ? 22 : 32
					};
				}
				else
				{
					element = new Border
					{
						Width = _settings.CompactMode ? 22 : 30,
						Height = _settings.CompactMode ? 22 : 30,
						BorderBrush = solidColorBrush2,
						BorderThickness = new Thickness(1.0),
						Child = new TextBlock
						{
							Text = effectState.Name.Equals("Temporary Hit Points", StringComparison.OrdinalIgnoreCase) ? "HP" : "?",
							Foreground = solidColorBrush2,
							HorizontalAlignment = HorizontalAlignment.Center,
							VerticalAlignment = VerticalAlignment.Center
						}
					};
				}
				grid.Children.Add(element);
				TextBlock element2 = new TextBlock
				{
					Text = effectState.Name,
					Foreground = Brushes.White,
					FontSize = 11.0,
					TextTrimming = TextTrimming.CharacterEllipsis,
					VerticalAlignment = VerticalAlignment.Center,
					Margin = new Thickness(4.0, 0.0, 3.0, 0.0)
				};
				Grid.SetColumn(element2, 1);
				grid.Children.Add(element2);
				TextBlock textBlock = new TextBlock
				{
					Text = Tracker.Display(effectState, Now),
					Foreground = solidColorBrush2,
					FontSize = (effectState.Permanent ? 11 : (_settings.CompactMode ? 12 : 15)),
					FontWeight = FontWeights.SemiBold,
					VerticalAlignment = VerticalAlignment.Center,
					HorizontalAlignment = HorizontalAlignment.Right
				};
				Grid.SetColumn(textBlock, 2);
				grid.Children.Add(textBlock);
				if (_settings.ShowDurationBars && effectState.Ends.HasValue && effectState.DurationSeconds > 0.0 && !effectState.Permanent)
				{
					if (_settings.FullRowDurationBars)
					{
						double num3 = Tracker.FractionRemaining(effectState, Now);
						Grid grid2 = new Grid
						{
							Tag = "DurationBackground",
							Height = _settings.CompactMode ? 22 : 32,
							Margin = new Thickness(2.0, 0.0, 0.0, 0.0),
							Background = new SolidColorBrush(Color.FromArgb(150, 12, 30, 18)),
							IsHitTestVisible = false,
							ClipToBounds = true,
							FlowDirection = FlowDirection.LeftToRight
						};
						grid2.ColumnDefinitions.Add(new ColumnDefinition
						{
							Width = new GridLength(num3, GridUnitType.Star)
						});
						grid2.ColumnDefinitions.Add(new ColumnDefinition
						{
							Width = new GridLength(1.0 - num3, GridUnitType.Star)
						});
						grid2.Children.Add(new Border
						{
							Background = new SolidColorBrush(Color.FromRgb(24, 110, 42))
						});
						Grid.SetColumn(grid2, 1);
						Grid.SetColumnSpan(grid2, 2);
						grid.Children.Insert(0, grid2);
						textBlock.Foreground = Brushes.White;
						textBlock.Margin = new Thickness(0.0, 0.0, 4.0, 0.0);
					}
					else
					{
						ProgressBar element3 = new ProgressBar
						{
							Minimum = 0.0,
							Maximum = 1.0,
							Value = Tracker.FractionRemaining(effectState, Now),
							Height = _settings.CompactMode ? 3 : 5,
							Margin = new Thickness(4.0, 1.0, 0.0, 3.0),
							Foreground = Brushes.LimeGreen,
							Background = new SolidColorBrush(Color.FromArgb(130, 25, 35, 30)),
							BorderThickness = new Thickness(0.0),
							IsHitTestVisible = false,
							FlowDirection = FlowDirection.LeftToRight
						};
						Grid.SetColumn(element3, 1);
						Grid.SetColumnSpan(element3, 2);
						Grid.SetRow(element3, 1);
						grid.Children.Add(element3);
					}
				}
				stackPanel.Children.Add(grid);
			}
			if (array2.Length == 0)
			{
				stackPanel.Children.Add(new TextBlock
				{
					Text = "—",
					Foreground = Brushes.Gray,
					Margin = new Thickness(8.0, 3.0, 0.0, 3.0)
				});
			}
			_body.Children.Add(stackPanel);
		}
		_body.Children.Add(_status);
	}
}




