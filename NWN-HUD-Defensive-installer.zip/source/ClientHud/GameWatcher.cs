using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace ClientHud;

public sealed class GameWatcher
{
	private readonly Application _app;

	private readonly DispatcherTimer _timer = new DispatcherTimer
	{
		Interval = TimeSpan.FromSeconds(2L)
	};

	private readonly int _session = Process.GetCurrentProcess().SessionId;

	private string _gameSession = "";

	private HudWindow? _window;

	private readonly EventWaitHandle _show = new EventWaitHandle(initialState: false, EventResetMode.AutoReset, "Local\\NWNClientHUD.Show");

	private readonly EventWaitHandle _exit = new EventWaitHandle(initialState: false, EventResetMode.AutoReset, "Local\\NWNClientHUD.Exit");

	public GameWatcher(Application app)
	{
		_app = app;
		_timer.Tick += delegate
		{
			Poll();
		};
	}

	public void Start()
	{
		Poll();
		_timer.Start();
	}

	public void Stop()
	{
		_timer.Stop();
		_show.Dispose();
		_exit.Dispose();
	}

	private void Poll()
	{
		if (_exit.WaitOne(0))
		{
			_app.Shutdown();
			return;
		}
		bool flag = _show.WaitOne(0);
		List<string> list = new List<string>();
		Process[] processesByName = Process.GetProcessesByName("nwmain");
		foreach (Process process in processesByName)
		{
			using (process)
			{
				try
				{
					if (process.SessionId == _session)
					{
						list.Add($"{process.Id}:{process.StartTime.Ticks}");
					}
				}
				catch (InvalidOperationException)
				{
				}
				catch (Win32Exception)
				{
				}
			}
		}
		string text = string.Join(";", list.OrderBy<string, string>((string value) => value, StringComparer.Ordinal));
		if (text == _gameSession)
		{
			if (flag && _window == null)
			{
				Open();
			}
			return;
		}
		_gameSession = text;
		_window?.Close();
		_window = null;
		if (text.Length != 0)
		{
			Open();
		}
	}

	private void Open()
	{
		_window = new HudWindow(preview: false);
		_app.MainWindow = _window;
		_window.Closed += delegate
		{
			_window = null;
		};
		_window.Show();
	}
}
