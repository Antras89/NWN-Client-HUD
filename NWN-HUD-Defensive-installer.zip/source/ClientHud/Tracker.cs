using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace ClientHud;

public sealed class Tracker
{
	private DateTimeOffset? _reportUntil;

	private int _year = DateTimeOffset.Now.Year;

	private readonly HashSet<string> _stances;

	private bool _hostileForceAttackConfirmed;

	private readonly HashSet<string> _confirmedLenses = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	private DateTimeOffset? _sanctuaryReady;

	private DateTimeOffset? _sanctuaryPulse;

	private static readonly Regex Prefix = new Regex("^\\[CHAT WINDOW TEXT\\] \\[(?<at>[^\\]]+)\\] (?<body>.*)$");

	private static readonly Regex Colours = new Regex("</?c[^>]*>");

	private static readonly TimeZoneInfo Zone = TimeZoneInfo.FindSystemTimeZoneById("Central European Standard Time");

	private static readonly HashSet<string> HealingEffects = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"Renewal", "Renewal I", "Renewal II", "Renewal III", "Infusion", "Infusion I", "Infusion II", "Regeneration", "Kolto Mist", "Temporary Hit Points",
		"Force Sanctuary", "Emergency Sealant", "Blood Weapon", "Guardian's Resolve", "Rest", "Hunger of the Dark", "Soul Ascension", "Soul Ascension Burst"
	};

	// Defensive effects verified against the SWLOR ability/icon catalog. Keep these
	// ahead of HealingEffects so hybrid defensive heals appear in one section only.
	private static readonly HashSet<string> DefensiveEffects = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"Absolute Defense", "Adamantine Guard", "Defensive Stance", "Force Warding",
		"Guarded Bite I", "Guarded Bite II", "Guarded Bite III", "Guarded Channel", "Guarded",
		"Guardian Reflexes", "Guardian's Resolve", "Guarding Bond Stance", "Guarding Roar I",
		"Guarding Roar II", "Guarding Roar III", "Guarding", "Guarding Step", "Impenetrable Guard",
		"Iron Guard Cover", "Iron Guard Stance", "Last Bastion Barrier", "Rayshield Screen I",
		"Rayshield Screen II", "Reflective Barrier", "Saber Ward", "Sentinel Guard", "Shielding I",
		"Shielding II", "Shielding III", "Shield Wall", "Twin Guard Stance", "Ward Bond",
		"Warden Wall Stance", "Warden Wall Stance Aura", "Warding Howl I", "Warding Howl II",
		"Warding Howl III", "Assault I", "Assault II", "Assault III", "Calibrated Field I",
		"Calibrated Field II", "Charge Order I", "Charge Order II", "Coagulant I", "Coagulant II",
		"Courageous Resolve", "Danger Sense", "Sense Danger", "Deflecting Aura", "Duelist Stance",
		"Evasive Challenge I", "Evasive Challenge II", "Evasive Combat", "Evasive Maneuver I",
		"Evasive Maneuver II", "Evasive Maneuver III", "Final Form", "Fortress Strike",
		"Harmonic Restoration", "Immovable Stance", "Iron Carapace", "Iron Wall Stance",
		"Lucid Splice", "Perfect Aegis", "Point Blank Burst", "Sentinel Stance",
		"Shelter Circle", "Skirmisher Stance", "Smoke Round Cover", "Steady Formation I",
		"Steady Formation II", "Stonewake Relay", "Tidecall Beacon", "Twin Intercept",
		"Unbreakable", "Unbreakable Beast", "Unmoving Center", "Untouchable Instinct",
		"Wayfinder Sensor"
	};

	public string Character { get; set; }

	public Dictionary<string, EffectState> Effects { get; } = new Dictionary<string, EffectState>(StringComparer.OrdinalIgnoreCase);

	public Dictionary<string, double> Learned { get; } = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

	public Dictionary<string, BuffDuration> BaseDurations { get; } = new Dictionary<string, BuffDuration>(StringComparer.OrdinalIgnoreCase);

	public DateTimeOffset? LastEvent { get; private set; }

	public bool EstimateSilentBuffRefreshes { get; set; }

	public bool HideStaleDebuffs { get; set; } = true;

	public HashSet<string> DebuffNames { get; } = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

	public Tracker(string character, IEnumerable<string>? stanceNames = null)
	{
		Character = character;
		_stances = new HashSet<string>(stanceNames ?? Array.Empty<string>(), StringComparer.OrdinalIgnoreCase);
	}

	public static bool IsHealingEffect(string name)
	{
		return HealingEffects.Contains(name);
	}

	public static bool IsDefensiveEffect(string name)
	{
		return DefensiveEffects.Contains(name);
	}

	public static bool IsBlazingSpikes(string name)
	{
		if (!name.Equals("Blazing Spikes", StringComparison.OrdinalIgnoreCase))
		{
			return name.Equals("Blazing Spike", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	private static string NormalizeName(string name)
	{
		if (!IsBlazingSpikes(name))
		{
			return name;
		}
		return "Blazing Spikes";
	}

	private bool IsStance(string name)
	{
		if (!IsBlazingSpikes(name))
		{
			if (!_stances.Contains(name))
			{
				return name.EndsWith(" Stance", StringComparison.OrdinalIgnoreCase);
			}
			return true;
		}
		return false;
	}

	private void SetPermanentStance(EffectState state)
	{
		state.Permanent = true;
		state.Ends = null;
		state.DurationSeconds = 0.0;
		state.Estimated = false;
		state.TimingSource = (IsBlazingSpikes(state.Name) ? "Permanent buff until deactivated or removed" : "Permanent stance until deactivated or replaced");
		Learned.Remove(state.Name);
	}

	private bool SelectStance(string name, DateTimeOffset at)
	{
		if (!IsStance(name))
		{
			return true;
		}
		EffectState[] array = Effects.Values.Where((EffectState e) => IsStance(e.Name) && !e.Name.Equals(name, StringComparison.OrdinalIgnoreCase)).ToArray();
		if (array.Any((EffectState e) => e.Applied > at))
		{
			return false;
		}
		EffectState[] array2 = array;
		foreach (EffectState effectState in array2)
		{
			Effects.Remove(effectState.Name);
		}
		return true;
	}

	public void Clear()
	{
		Effects.Clear();
		_reportUntil = null;
		LastEvent = null;
		_hostileForceAttackConfirmed = false;
		_confirmedLenses.Clear();
		_sanctuaryReady = null;
		_sanctuaryPulse = null;
	}

	public bool Feed(string raw)
	{
		if (raw.StartsWith("Messages for:", StringComparison.Ordinal))
		{
			Clear();
			Match match = Regex.Match(raw, "\\b(20\\d\\d)\\s*$");
			if (match.Success)
			{
				_year = int.Parse(match.Value.Trim());
			}
			return true;
		}
		Match match2 = Prefix.Match(raw.TrimEnd('\r'));
		if (!match2.Success)
		{
			return false;
		}
		if (!DateTime.TryParseExact(Regex.Replace(match2.Groups["at"].Value, "\\s+", " ") + " " + _year, "ddd MMM d HH:mm:ss yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var result))
		{
			return false;
		}
		DateTimeOffset dateTimeOffset = new DateTimeOffset(TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(result, DateTimeKind.Unspecified), Zone));
		string text = Colours.Replace(match2.Groups["body"].Value, "").Trim();
		if (text == "Welcome to Star Wars: Legends of the Old Republic!")
		{
			Clear();
			return true;
		}
		LastEvent = dateTimeOffset;
		if (text == Character + " readies Force Sanctuary.")
		{
			_sanctuaryReady = dateTimeOffset;
			return false;
		}
		if (EstimateSilentBuffRefreshes)
		{
			Match match3 = Regex.Match(text, "^Restored (?<amount>\\d+) (?<resource>FP|STM)\\.$");
			if (match3.Success && long.TryParse(match3.Groups["amount"].Value, out var result2) && result2 > 0)
			{
				string text2 = ((match3.Groups["resource"].Value == "FP") ? "Force Lens: Force Attack" : "Force Lens: Attack");
				if (_confirmedLenses.Contains(text2))
				{
					Effects[text2] = new EffectState
					{
						Name = text2,
						Applied = dateTimeOffset,
						Ends = dateTimeOffset.AddSeconds(30.0),
						DurationSeconds = 30.0,
						Estimated = true,
						TimingSource = "Estimated Force Lens renewal from resource restoration; 30-second public source baseline. Unlogged regeneration cannot be detected."
					};
					return true;
				}
			}
		}
		if (EstimateSilentBuffRefreshes && _hostileForceAttackConfirmed && Regex.IsMatch(text, "^" + Regex.Escape(Character) + "(?: \\[[^\\]]+\\])? uses .+ on .+: \\*(?:hit|miss|critical)\\* :"))
		{
			double num = BaseDurations.GetValueOrDefault("Hostile Ability Force Attack")?.Seconds ?? 30.0;
			if (num <= 0.0 || num > 31536000.0 || !double.IsFinite(num))
			{
				num = 30.0;
			}
			Effects["Hostile Ability Force Attack"] = new EffectState
			{
				Name = "Hostile Ability Force Attack",
				Applied = dateTimeOffset,
				Ends = dateTimeOffset.AddSeconds(num),
				DurationSeconds = num,
				Estimated = true,
				TimingSource = "Estimated renewal from a combat ability receipt; SWLOR suppresses this buff's application messages. Base duration may differ on the server."
			};
			return true;
		}
		if ((text == "Status Effects:" || text == "Buffs/Debuffs:") ? true : false)
		{
			_reportUntil = dateTimeOffset.AddSeconds(3.0);
			return false;
		}
		Match match4 = Regex.Match(text, "^" + Regex.Escape(Character) + " receives the effect of (?<effect>.+?)(?: from (?<source>.+?))?\\.?$");
		if (match4.Success)
		{
			string text3 = NormalizeName(match4.Groups["effect"].Value);
			string textSource = match4.Groups["source"].Value;
			if (text3.Equals("Force Sanctuary", StringComparison.OrdinalIgnoreCase))
			{
				bool flag = _sanctuaryReady.HasValue && dateTimeOffset >= _sanctuaryReady.Value && (dateTimeOffset - _sanctuaryReady.Value).TotalSeconds <= 10.0;
				bool num2 = _sanctuaryPulse.HasValue && dateTimeOffset >= _sanctuaryPulse.Value && (dateTimeOffset - _sanctuaryPulse.Value).TotalSeconds <= 5.0;
				_sanctuaryPulse = dateTimeOffset;
				_sanctuaryReady = null;
				_reportUntil = null;
				Learned.Remove(text3);
				if (num2 && !flag && Effects.ContainsKey(text3))
				{
					return false;
				}
				Effects[text3] = new EffectState
				{
					Name = text3,
					Applied = dateTimeOffset,
					Ends = dateTimeOffset.AddSeconds(30.0),
					DurationSeconds = 30.0,
					HasApplicationEvent = true,
					Estimated = true,
					TimingSource = "30-second sanctuary timer from first application; healing pulses do not restart it."
				};
				return true;
			}
			if (!SelectStance(text3, dateTimeOffset))
			{
				return false;
			}
			if (text3.Equals("Perfect Aegis", StringComparison.OrdinalIgnoreCase))
			{
				Effects.Remove("Saber Ward");
			}
			else if (text3.Equals("Saber Ward", StringComparison.OrdinalIgnoreCase))
			{
				Effects.Remove("Perfect Aegis");
			}
			EffectState effectState = new EffectState
			{
				Name = text3,
				Applied = dateTimeOffset,
				HasApplicationEvent = true
			};
			BuffDuration value;
			double value2;
			BuffDuration value3;
			if (text3.Equals("Hasten I", StringComparison.OrdinalIgnoreCase) && textSource.Contains("Snap Rush", StringComparison.OrdinalIgnoreCase))
			{
				effectState.Ends = dateTimeOffset.AddSeconds(15.0);
				effectState.DurationSeconds = 15.0;
				effectState.Estimated = true;
				effectState.TimingSource = "Fixed 15-second Hasten I duration from Snap Rush in SWLOR server source.";
			}
			else if (IsStance(text3) || IsBlazingSpikes(text3))
			{
				SetPermanentStance(effectState);
			}
			else if (BaseDurations.TryGetValue(text3, out value) && value.Fixed && value.Seconds > 0.0 && value.Seconds <= 31536000.0 && double.IsFinite(value.Seconds))
			{
				effectState.Ends = dateTimeOffset.AddSeconds(value.Seconds);
				effectState.DurationSeconds = value.Seconds;
				effectState.Estimated = true;
				effectState.TimingSource = "Fixed skill duration from public source; log reports can correct this instance.";
			}
			else if (Learned.TryGetValue(text3, out value2) && value2 > 0.0 && double.IsFinite(value2))
			{
				effectState.Ends = dateTimeOffset.AddSeconds(value2);
				effectState.DurationSeconds = value2;
				effectState.Estimated = true;
				effectState.TimingSource = "Learned duration from game log";
			}
			else if (BaseDurations.TryGetValue(text3, out value3) && value3.Seconds > 0.0 && value3.Seconds <= 31536000.0 && double.IsFinite(value3.Seconds))
			{
				effectState.Ends = dateTimeOffset.AddSeconds(value3.Seconds);
				effectState.DurationSeconds = value3.Seconds;
				effectState.Estimated = true;
				effectState.TimingSource = "SWLOR source base duration. " + value3.Notes;
			}
			Effects[text3] = effectState;
			_reportUntil = null;
			return true;
		}
		Match match5 = Regex.Match(text, "^" + Regex.Escape(Character) + "'s (?<effect>.+) effect has worn off\\.$");
		if (match5.Success)
		{
			string text4 = NormalizeName(match5.Groups["effect"].Value);
			if (text4.Equals("Force Sanctuary", StringComparison.OrdinalIgnoreCase) && Effects.TryGetValue(text4, out EffectState value4) && value4.HasApplicationEvent)
			{
				return false;
			}
			return Effects.Remove(text4);
		}
		Match match6 = Regex.Match(text, "^(?<effect>.+) deactivated\\.$");
		if (match6.Success && (IsStance(match6.Groups["effect"].Value) || IsBlazingSpikes(match6.Groups["effect"].Value)))
		{
			return Effects.Remove(NormalizeName(match6.Groups["effect"].Value));
		}
		if (!_reportUntil.HasValue || dateTimeOffset > _reportUntil.Value)
		{
			return false;
		}
		Match match7 = Regex.Match(text, "^(?<name>.+):\\s+(?<time>(?:\\d+:)?\\d+:\\d{2}|Indefinite)$");
		if (!match7.Success)
		{
			return false;
		}
		string text5 = NormalizeName(match7.Groups["name"].Value.Trim());
		if (text5.Equals("Force Lens: Attack", StringComparison.OrdinalIgnoreCase) || text5.Equals("Force Lens: Force Attack", StringComparison.OrdinalIgnoreCase))
		{
			_confirmedLenses.Add(text5);
		}
		if (text5.Equals("Hostile Ability Force Attack", StringComparison.OrdinalIgnoreCase))
		{
			_hostileForceAttackConfirmed = true;
		}
		if (!SelectStance(text5, dateTimeOffset))
		{
			return false;
		}
		EffectState value5;
		bool flag2 = Effects.TryGetValue(text5, out value5);
		if (text5.Equals("Force Sanctuary", StringComparison.OrdinalIgnoreCase) && value5 != null && value5.HasApplicationEvent)
		{
			return false;
		}
		if (value5 == null)
		{
			value5 = new EffectState
			{
				Name = text5,
				Applied = dateTimeOffset
			};
		}
		value5.LastConfirmed = dateTimeOffset;
		value5.TimingSource = "Remaining duration reported in game log";
		if (IsStance(text5) || IsBlazingSpikes(text5))
		{
			SetPermanentStance(value5);
		}
		else if (match7.Groups["time"].Value == "Indefinite")
		{
			value5.Ends = null;
			value5.DurationSeconds = 0.0;
			value5.Permanent = true;
			value5.Estimated = false;
		}
		else
		{
			double[] array = match7.Groups["time"].Value.Split(':').Select(double.Parse).ToArray();
			double num3 = ((array.Length == 3) ? (array[0] * 3600.0 + array[1] * 60.0 + array[2]) : (array[0] * 60.0 + array[1]));
			if (!double.IsFinite(num3) || num3 > 31536000.0)
			{
				return false;
			}
			if (num3 == 0.0 && text5.Equals("Temporary Hit Points", StringComparison.OrdinalIgnoreCase))
			{
				Effects.Remove(text5);
				Learned.Remove(text5);
				return true;
			}
			bool flag3 = BaseDurations.GetValueOrDefault(text5)?.Fixed ?? false;
			if (!flag3 && flag2 && value5.HasApplicationEvent && dateTimeOffset >= value5.Applied && (dateTimeOffset - value5.Applied).TotalSeconds < 86400.0)
			{
				Learned[text5] = num3 + (dateTimeOffset - value5.Applied).TotalSeconds;
			}
			value5.Ends = dateTimeOffset.AddSeconds(num3);
			value5.DurationSeconds = (flag3 ? Math.Max(num3, BaseDurations[text5].Seconds) : (value5.HasApplicationEvent ? Math.Max(num3, Learned.GetValueOrDefault(text5, num3)) : num3));
			value5.Permanent = false;
			value5.Estimated = false;
		}
		Effects[text5] = value5;
		return true;
	}

	public IEnumerable<EffectState> Active(DateTimeOffset now)
	{
		return (from e in Effects.Values
			where !e.Ends.HasValue || e.Ends > now
			where !HideStaleDebuffs || !DebuffNames.Contains(e.Name) || e.Permanent || e.Ends.HasValue || now < (e.LastConfirmed ?? e.Applied).AddSeconds(60.0)
			orderby (!e.Permanent) ? ((!e.Ends.HasValue) ? double.NegativeInfinity : (e.Ends.Value - now).TotalSeconds) : double.PositiveInfinity descending
			select e).ThenBy<EffectState, string>((EffectState e) => e.Name, StringComparer.OrdinalIgnoreCase);
	}

	public static string Display(EffectState e, DateTimeOffset now)
	{
		if (e.Permanent)
		{
			if (!IsBlazingSpikes(e.Name))
			{
				return "Permanent";
			}
			return "∞";
		}
		if (!e.Ends.HasValue)
		{
			return string.Empty;
		}
		long num = (long)Math.Ceiling(Math.Max(0.0, (e.Ends.Value - now).TotalSeconds));
		return (e.Estimated ? "~" : "") + ((num >= 3600) ? $"{num / 3600}:{num / 60 % 60:00}:{num % 60:00}" : $"{num / 60}:{num % 60:00}");
	}

	public static double FractionRemaining(EffectState effect, DateTimeOffset now)
	{
		if (!effect.Permanent && effect.Ends.HasValue && !(effect.DurationSeconds <= 0.0))
		{
			return Math.Clamp((effect.Ends.Value - now).TotalSeconds / effect.DurationSeconds, 0.0, 1.0);
		}
		return 0.0;
	}
}



