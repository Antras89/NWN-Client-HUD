using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace ClientHud;

internal static class CharacterNameDetector
{
	private static readonly Regex ChatLine = new Regex("^\\[CHAT WINDOW TEXT\\] \\[(?<at>[^\\]]+)\\] (?<body>.*)$");

	private static readonly Regex Colours = new Regex("</?c[^>]*>");

	private static readonly Regex[] ReadiesPatterns =
	{
		new Regex("^(?<name>.+?) readies .+\\.$"),
		new Regex("^(?<name>.+?)(?: \\[[^\\]]+\\])? uses .+ on .+: \\*(?:hit|miss|critical)\\* :")
	};

	private static readonly Regex[] EffectPatterns =
	{
		new Regex("^(?<name>.+?) receives the effect of .+$"),
		new Regex("^(?<name>.+?)'s .+ effect has worn off\\.$")
	};

	public static string? Detect(string path)
	{
		string? latestAbilityUser = null;
		string? latestEffectRecipient = null;

		using FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
		using StreamReader reader = new StreamReader(stream);
		string? line;
		while ((line = reader.ReadLine()) != null)
		{
			Match chat = ChatLine.Match(line.TrimEnd('\r'));
			if (!chat.Success)
			{
				continue;
			}

			string body = Colours.Replace(chat.Groups["body"].Value, "").Trim();
			string? name = CaptureName(body, ReadiesPatterns);
			if (!string.IsNullOrWhiteSpace(name))
			{
				latestAbilityUser = name.Trim();
				continue;
			}

			name = CaptureName(body, EffectPatterns);
			if (!string.IsNullOrWhiteSpace(name))
			{
				latestEffectRecipient = name.Trim();
			}
		}

		return latestAbilityUser ?? latestEffectRecipient;
	}

	private static string? CaptureName(string body, IEnumerable<Regex> patterns)
	{
		foreach (Regex pattern in patterns)
		{
			Match match = pattern.Match(body);
			if (match.Success)
			{
				return match.Groups["name"].Value;
			}
		}

		return null;
	}
}
