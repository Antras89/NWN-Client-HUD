using System;
using System.IO;
using System.Linq;
using System.Text;

namespace ClientHud;

public sealed class LogTail
{
	private readonly string _path;

	private long _offset;

	private string? _identity;

	private string _partial = "";

	private Decoder _decoder = Encoding.UTF8.GetDecoder();

	public Action<string>? OnTrackedEvent { get; set; }

	public DateTimeOffset? LastReadAt { get; private set; }

	public LogTail(string path)
	{
		_path = path;
	}

	public void Refresh(Tracker tracker)
	{
		using FileStream fileStream = new FileStream(_path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
		byte[] array = new byte[128];
		int num = fileStream.Read(array);
		_identity = ((num == array.Length) ? Convert.ToBase64String(array) : null);
		_offset = fileStream.Length;
		_partial = "";
		_decoder.Reset();
		tracker.Clear();
	}

	public void Rewind(Tracker tracker)
	{
		_offset = 0L;
		_identity = null;
		_partial = "";
		_decoder.Reset();
		tracker.Clear();
	}

	public void Poll(Tracker tracker)
	{
		using FileStream fileStream = new FileStream(_path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
		byte[] array = new byte[128];
		string text = ((fileStream.Read(array) == array.Length) ? Convert.ToBase64String(array) : null);
		if (fileStream.Length < _offset || (_identity != null && text != null && text != _identity))
		{
			_offset = 0L;
			_partial = "";
			_decoder.Reset();
			tracker.Clear();
		}
		if (text != null)
		{
			_identity = text;
		}
		fileStream.Position = _offset;
		long num = Math.Min(4194304L, fileStream.Length - _offset);
		if (num == 0L)
		{
			return;
		}
		byte[] array2 = new byte[(int)Math.Min(262144L, num)];
		char[] array3 = new char[Encoding.UTF8.GetMaxCharCount(array2.Length)];
		while (num > 0)
		{
			int num2 = fileStream.Read(array2, 0, (int)Math.Min(array2.Length, num));
			if (num2 == 0)
			{
				break;
			}
			_offset += num2;
			LastReadAt = DateTimeOffset.Now;
			num -= num2;
			int chars = _decoder.GetChars(array2, 0, num2, array3, 0, flush: false);
			string[] array4 = (_partial + new string(array3, 0, chars)).Split('\n');
			foreach (string item in array4.SkipLast(1))
			{
				if (tracker.Feed(item))
				{
					OnTrackedEvent?.Invoke(item.TrimEnd('\r'));
				}
			}
			_partial = array4[^1];
		}
	}
}
