$ErrorActionPreference = 'Stop'

$package = $PSScriptRoot
$target = Join-Path $env:LOCALAPPDATA 'Programs\NWN Client HUD'
$backupRoot = Join-Path $env:LOCALAPPDATA 'NWN Client HUD Backups'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $backupRoot $stamp
$desktopDirectory = [Environment]::GetFolderPath('DesktopDirectory')
$shortcutPath = Join-Path $desktopDirectory 'NWN Client HUD.lnk'
$shortcutBackup = Join-Path $backup 'NWN Client HUD.lnk'
$shortcutCreated = $false
$files = @(
    'NWN.ClientHUD.exe',
    'NWN.ClientHUD.dll',
    'NWN.ClientHUD.deps.json',
    'NWN.ClientHUD.runtimeconfig.json',
    'hud-icon.ico',
    'icons.json',
    'buff-durations.json',
    'learned-defaults.json'
)
$directories = @('icons')
$configFiles = @('settings.json', 'learned.json')
$createdFiles = [System.Collections.Generic.List[string]]::new()
$createdDirectories = [System.Collections.Generic.List[string]]::new()

foreach ($name in ($files + $configFiles + $directories)) {
    if (!(Test-Path -LiteralPath (Join-Path $package $name))) {
        throw "Package is incomplete; missing $name"
    }
}

New-Item -ItemType Directory -Path $target -Force | Out-Null
New-Item -ItemType Directory -Path $backup -Force | Out-Null

$exitExe = Join-Path $target 'NWN.ClientHUD.exe'
if (Test-Path -LiteralPath $exitExe) {
    $exitProcess = Start-Process -FilePath $exitExe -ArgumentList '--exit' -WindowStyle Hidden -PassThru
    if (!$exitProcess.WaitForExit(10000)) { throw 'HUD exit request did not complete; no files were replaced.' }
    foreach ($running in @(Get-Process -Name 'NWN.ClientHUD' -ErrorAction SilentlyContinue)) {
        try {
            if ($running.Path -eq $exitExe -and !$running.WaitForExit(10000)) {
                throw 'HUD is still running; no files were replaced.'
            }
        } catch [System.InvalidOperationException] { }
    }
}

try {
    foreach ($name in $files) {
        $sourcePath = Join-Path $package $name
        $targetPath = Join-Path $target $name
        if (Test-Path -LiteralPath $targetPath) {
            Copy-Item -LiteralPath $targetPath -Destination (Join-Path $backup $name) -Force
        } else {
            $createdFiles.Add($targetPath)
        }
        Copy-Item -LiteralPath $sourcePath -Destination $targetPath -Force
    }

    foreach ($name in $directories) {
        $sourcePath = Join-Path $package $name
        $targetPath = Join-Path $target $name
        if (Test-Path -LiteralPath $targetPath) {
            Copy-Item -LiteralPath $targetPath -Destination (Join-Path $backup $name) -Recurse -Force
        } else {
            $createdDirectories.Add($targetPath)
        }
        Copy-Item -LiteralPath $sourcePath -Destination $targetPath -Recurse -Force
    }

    foreach ($name in $configFiles) {
        $targetPath = Join-Path $target $name
        if (!(Test-Path -LiteralPath $targetPath)) {
            Copy-Item -LiteralPath (Join-Path $package $name) -Destination $targetPath
            $createdFiles.Add($targetPath)
        }
    }

    if (Test-Path -LiteralPath $shortcutPath) {
        Copy-Item -LiteralPath $shortcutPath -Destination $shortcutBackup -Force
    }
    $shell = New-Object -ComObject WScript.Shell
    try {
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $exitExe
        $shortcut.WorkingDirectory = $target
        $shortcut.IconLocation = Join-Path $target 'hud-icon.ico'
        $shortcut.Description = 'Launch NWN Client HUD'
        $shortcutCreated = $true
        $shortcut.Save()
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($shortcut)
    } finally {
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($shell)
    }

    Start-Process -FilePath $exitExe -WindowStyle Hidden
    Write-Host "NWN Client HUD updated. Existing settings and learned data were retained."
    Write-Host "Desktop shortcut: $shortcutPath"
    Write-Host "Backup: $backup"
} catch {
    foreach ($name in $files) {
        $backupPath = Join-Path $backup $name
        $targetPath = Join-Path $target $name
        if (Test-Path -LiteralPath $backupPath) {
            Copy-Item -LiteralPath $backupPath -Destination $targetPath -Recurse -Force
        }
    }
    foreach ($name in $directories) {
        $backupPath = Join-Path $backup $name
        $targetPath = Join-Path $target $name
        if (Test-Path -LiteralPath $backupPath) {
            if (Test-Path -LiteralPath $targetPath) { Remove-Item -LiteralPath $targetPath -Recurse -Force }
            Copy-Item -LiteralPath $backupPath -Destination $targetPath -Recurse -Force
        }
    }
    foreach ($path in $createdFiles) {
        if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force }
    }
    foreach ($path in $createdDirectories) {
        if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
    }
    if (Test-Path -LiteralPath $shortcutBackup) {
        Copy-Item -LiteralPath $shortcutBackup -Destination $shortcutPath -Force
    } elseif ($shortcutCreated -and (Test-Path -LiteralPath $shortcutPath)) {
        Remove-Item -LiteralPath $shortcutPath -Force
    }
    if (Test-Path -LiteralPath $exitExe) { Start-Process -FilePath $exitExe -WindowStyle Hidden }
    throw
}
